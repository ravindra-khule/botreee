<div id="display_type_selector">
	
</div>