<?php

interface I_Displayed_Gallery_Mapper
{
	
}