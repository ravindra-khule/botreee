<?php

interface I_Display_Settings_Controller
{
	
}