<?php

interface I_Displayed_Gallery extends I_DataMapper_Model
{

}
