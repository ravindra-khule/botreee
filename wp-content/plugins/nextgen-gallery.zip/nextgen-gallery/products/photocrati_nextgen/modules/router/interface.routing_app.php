<?php

interface I_Routing_App
{
	function passthru();
}