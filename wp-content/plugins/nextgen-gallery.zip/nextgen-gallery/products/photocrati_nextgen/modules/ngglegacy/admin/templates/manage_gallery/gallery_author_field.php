<span class="field gallery_author_field">
	<?php echo esc_html($author)?>
</span>